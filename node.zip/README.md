`cd custom_nodes`

`git clone https://github.com/GavChap/ComfyUI-CascadeResolutions .`

You'll get a new node called Cascade Resolutions, you can pick the x and y sizes from a list.
![Image Description](https://github.com/al-swaiti/ComfyUI-CascadeResolutions/blob/main/preview.png)

